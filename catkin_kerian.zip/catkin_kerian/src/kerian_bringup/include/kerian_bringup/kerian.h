#ifndef KERIAN_H
#define KERIAN_H


#include <ros/ros.h>
#include <ros/time.h>
#include <geometry_msgs/TransformStamped.h>
#include <geometry_msgs/Twist.h>
#include </opt/ros/melodic/include/tf2_ros/transform_broadcaster.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <boost/asio.hpp>

namespace Robot
{
	class Kerian
	{
		public:
			Kerian();
			~Kerian();
			bool init();
			bool spinOnce(float Vec_X,float Vec_A);
			void SetExceptVec(float Vec_X,float Vec_A);
		
		private:
			bool ReadSpeed();
			void WriteSpeed();
			bool dataCheck(unsigned char* ptr);
			void ExpectPositiveKinematics();//正向运动学计算里程计
			void MeasurePositiveKinematics();
			void InverseKinematics();//逆向运动学计算左右轮转速
			void ExpectPositionEstimation();//期望位姿估计
			void MeasurePositionEstimation();//测量位姿估计
			void ComplementaryOptionalPositionEstimation();
			
			void CalcDynamicWidth(float vecLeft,float vecRight);//计算轮间宽度
			void InverseCalcDynamicWidth(float Vec_x,float Vec_A);
			void MeasureEncoderToVelocity();
			
		private:
			ros::Time Expect_CurrentTime,Expect_LastTime;
			ros::Time Measure_CurrentTime,Measure_LastTime;
			
			float 	Optinal_Pos_X;
			float 	Optinal_Pos_Y;
			float 	Optinal_Pos_A;
			
			float 	Expect_Pos_X;
			float 	Expect_Pos_Y;
			float	Expect_Pos_A;
			
			float 	Expect_Vec_X;
			float 	Expect_Vec_Y;
			float 	Expect_Vec_A;
			
			float 	Expect_Vec_Left;
			float 	Expect_Vec_Right;
			
			int8_t  Expect_Encoder_Left;
			int8_t  Expect_Encoder_Right;
			
			
			float 	Measure_Pos_X;
			float 	Measure_Pos_Y;
			float  	Measure_Pos_A;
			float  	Measure_Pos_Last_A;
			
			float 	Measure_Vec_X;
			float 	Measure_Vec_A;
			
			float 	Measure_Vec_Left;
			float 	Measure_Vec_Right;
			
			int8_t  Measure_Encoder_Left;
			int8_t  Measure_Encoder_Right;
			
			
			/*
				  
				下发机器人期望速度 
						Expect_Vec_X
						Expect_Vec_A
				下发左右轮期望速度
						Expect_Vec_Left
						Expect_Vec_Right
				下发左右轮期望增量编码值
						Expect_Encoder_Left
						Expect_Encoder_Right
				
				测量左右轮编码值
						Measure_Encoder_Left
						Measure_Encoder_Right
				测量左右轮速度
						Measure_Vec_Left
						Measure_Vec_Right
				测量机器人速度
						Measure_Vec_X
						Measure_Vec_A
				世界坐标系机器人期望位置
						Expect_Pos_X
						Expect_Pos_Y
						Expect_Pos_A
				世界坐标系机器人测量位置
						Measure_Pos_X
						Measure_Pos_Y
						Measure_Pos_A
			*/
			
		float DynamicWidth;
			
		ros::NodeHandle nh;
		ros::Publisher odomPub;//publish the odometry messages
		//tf::TransformBroadcaster odom_broadcaster_;
		tf2_ros::TransformBroadcaster odom_broadcaster; //broadcast the tf messages
	};
}

#endif
