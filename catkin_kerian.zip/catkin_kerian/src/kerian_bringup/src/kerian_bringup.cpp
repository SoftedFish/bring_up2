#include "kerian_bringup/kerian.h"

float Vec_x;
float Vec_A;

void callBack(const geometry_msgs::Twist& msg)
{
	Vec_x = msg.linear.x;
	Vec_A = msg.angular.z;
}

int main(int argc,char** argv)
{
	ros::init(argc,argv,"kerian_bringup");
	ros::NodeHandle n;
	
	Robot::Kerian  kerian;
	
	if (!kerian.init())
		ROS_ERROR("Kerian initialized failed ");
	
	ROS_INFO("Kerain initialized successful");
	
	ros::Subscriber sub = n.subscribe("cmd_vel",50,callBack);
	
	ros::Rate loop_rate(50);
	
	while(ros::ok())
	{
		ros::spinOnce();
		
		kerian.spinOnce(Vec_x,Vec_A);
		loop_rate.sleep();
	}
	
	return 0;
}
